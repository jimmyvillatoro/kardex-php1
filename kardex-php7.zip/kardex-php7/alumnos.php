<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Sistema Kardex</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';


$Idalu = utf8_decode($_GET['Idalu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idsal = utf8_decode($_GET['Idsal']);

$men = utf8_decode($_GET['men']);



$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Idesc, Foto FROM alumnos  WHERE Idalu = '".$Idalu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row['Nombres'];

    $Apellidos=$row['Apellidos'];

    $Idescl=$row['Idesc'];
    $foto=$row['Foto'];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Control <span> Kardex</span></h1>

				<p>Area de Alumnos</p>

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="alumnos.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>" title="" class="round active">Area de Alumnos</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>				

						

					



 <h3>Soporte</h3>

						<ul>

			 <li>Ticket</li>

    <li>Chat</li>

						</ul>

					

					<!-- End Sidebar -->				

					</div>

					

					<div id="content" class="round">

					



<p>Alumno:<a style="color:orange;"> <?php echo $Nombres; ?> <?php echo $Apellidos; ?></a></p>



<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);

 ?> </a></p>

<?php

$dir = 'dat/alumnos/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='right'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?>

<div id="wrapper2" class="round">					

<div id="sidebar2" class="round">					

<h3>Instituto</h3>					

<ul>


<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);



if($Idesc<0)
$Idesc=$Idescl;



$resultado1=mysqli_query($db_connection, "SELECT Idesc, Escuela FROM escuelas WHERE  Estado=1 && Idesc='".$Idesc."' ORDER BY Idesc  ");



if (mysqli_num_rows($resultado1)>0)

{			  

      while ($row1 =mysqli_fetch_array($resultado1)) 

	  {

   $Idesc1=$row1['Idesc'];

	  $Escuela=$row1['Escuela'];



?>

<li> <a style="color:orange;" > <?php echo $Escuela; ?> </a> </li>



<?php

      }

}

mysqli_free_result($resultado1);

mysqli_close($db_connection);

 ?>				

</ul>



			

<h3>Carrera</h3>

<ul>

<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);





$resultado2=mysqli_query($db_connection, "SELECT Idcar, Carrera FROM carreras WHERE  Idesc='".$Idesc."' ORDER BY Idcar ");



if (mysqli_num_rows($resultado2)>0)

{			  

      while ($row2 =mysqli_fetch_array($resultado2)) 

	  {

   $Idcar2=$row2['Idcar'];

	  $Carrera=$row2['Carrera'];



?> 

<li><a style="color:orange;" > <?php echo $Carrera; ?>  </a> </li>




<?php

      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>





<h3>Ciclo</h3>

<ul>



<?php

include 'dat/cdb/db.php';



$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);





$resultado3=mysqli_query($db_connection, "SELECT Idcic, Ciclo FROM ciclos WHERE  Idcar='".$Idcar."' ORDER BY Idcic ");



if (mysqli_num_rows($resultado3)>0)

{			  

      while ($row3 =mysqli_fetch_array($resultado3)) 

	  {

   $Idcic3=$row3['Idcic'];

	  $Ciclo=$row3['Ciclo'];



?> 

<li> <a style="color:orange;" >  <?php echo $Ciclo; ?> </a>

 </li>



<?php

      }

}

mysqli_free_result($resultado3);

mysqli_close($db_connection);

 ?>				



</ul>



<h3>Salón</h3>

<ul>




<?php

include 'dat/cdb/db.php';



$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);





$resultado4=mysqli_query($db_connection, "SELECT Idsal, Turno, Grado, Grupo FROM salones WHERE  Idcic='".$Idcic."' ORDER BY Idsal ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

   $Idsal4=$row4['Idsal'];

	  $Turno=$row4['Turno'];

   $Grado=$row4['Grado'];

   $Grupo=$row4['Grupo'];



?> 

<li> <a style="color:orange;" >   <?php echo $Turno; ?> <?php echo $Grado; ?> <?php echo $Grupo; ?>  </a>  

 </li>


<li> Ver Horarios<a href="verhora.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/> </a></li>

<li> Ver Calificaciones<a href="vercala.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/> </a></li>

<li> Ver Pagos<a href="verpaga.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/> </a></li>


<?php

      }

}

mysqli_free_result($resultado4);

mysqli_close($db_connection);

 ?>				

</ul>






<h3>Control de tú perfil</h3>					

<ul>

<li align="center">

<a href="actalu.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/user.jpeg" alt="" width="200" height="150"  class="round" /> </a></li>

<li align="center"><a href="actalu.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>">Actualiza tú perfil <img src="dat/ima/perfil.png" alt="" width="40" height="40"  class="round"/></a></li>				

		<li align="center"><a href="cargara.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>">Asignar Foto <img src="dat/ima/next.jpeg" alt="" width="40" height="40"  class="round"/></a></li>	

</ul>





<div id="splash" align="center">

<img src="dat/ima/kardexb.png" alt="" width="600" height="300" class="round" align="center" />

				</div>



<!-- End Sidebar -->

</div>



    </div>

					

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

	<div id="footer">

			

<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>

</body>

	



</html>









