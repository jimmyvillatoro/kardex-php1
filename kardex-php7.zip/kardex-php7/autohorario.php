<?php
include 'dat/cdb/db.php';

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idsal = $_REQUEST['Idsal'];
$acc = $_REQUEST['acc'];
//docentesh dia=letra
//detalleh  dia=letra

$l="Lunes";
$ma="Martes";
$mi="Miércoles";
$j="Jueves";
$v="Viernes";
$s="Sábado";
$d="Domingo";
$lv="Lunes - Viernes";
$sd="Sábado - Domingo";
$ld="Lunes - Domingo";


//suma de horas a asignar y suma horas asignadas

$r0=mysqli_query($db_connection, "SELECT sum(d.Horas) Horas, sum(d.Asignadas) Asignadas FROM detallemd d, ciclos c, materias m, carreras ca WHERE d.Idcic= '".$Idcic."'  && m.Idcar=ca.Idcar && d.Idmat=m.Idmat   && c.Estado=1 && d.Idcic=c.Idcic && d.Asignadas < d.Horas ORDER BY d.Idmat");


if (mysqli_num_rows($r0)>0)
while ($row0 =mysqli_fetch_array($r0)){
 $nhc=$row0['Horas'];
 $nha=$row0['Asignadas'];
}

if($acc==0)
{
//mientras haya horas a asignar en el salón

$cuenta=0;

$r1=mysqli_query($db_connection, "SELECT d.Horas, d.Asignadas, d.Iddoc, d.Idmat, d.Idcic, d.Idmd, m.Materia, ca.Carrera, ca.Dia, ca.Idcar, s.Idsal FROM detallemd d, ciclos c, salones s, materias m, carreras ca WHERE d.Idcic= '".$Idcic."' && m.Idcar=ca.Idcar && d.Idmat=m.Idmat   && c.Estado=1 && d.Idcic=c.Idcic && s.Idcic=c.Idcic && s.Idsal= '".$Idsal."' && d.Asignadas < d.Horas ORDER BY d.Idmat");

if (mysqli_num_rows($r1)>0)
while ($row1 =mysqli_fetch_array($r1)){

 $Idmdx=$row1['Idmd'];
 $Iddocx=$row1['Iddoc'];
 $H=$row1['Horas'];
 $A=$row1['Asignadas'];
 $D=$row1['Dia'];


$men="mientras haya horas a asignar en el salón";

if($D==$lv)
{

$cuenta++;

$men="carrera dia".$Iddocx;
// horario libre del docente

$r2=mysqli_query($db_connection, "SELECT Iddh, Dia, Horario FROM docentesh WHERE Iddoc='".$Iddocx."' && Estado=1");

if(mysqli_num_rows($r2)>0)
while ($row2 =mysqli_fetch_array($r2)){
    $Iddhx=$row2['Iddh'];
   	$diad=$row2['Dia'];
    $horariod=$row2['Horario'];

// horario del salón detalleh 

$men="horario del salón";

$r3=mysqli_query($db_connection, "SELECT Dia, Horario FROM detalleh WHERE Dia= '".$diad."' && Horario= '".$horariod."' && Idsal='".$Idsal."' ");

//Idmd='".$Idmdx."' && Iddh='".$Iddhx."' 

//si día está dentro del rango lv

if(mysqli_num_rows($r3)<=0)
if($diad==$l || $diad==$ma || $diad==$mi || $diad==$j || $diad==$v )
{
$men="rango del día";
//asigna hora

$insert_value = "INSERT INTO detalleh (Horas, Dia, Horario,   Idmd, Iddh, Idsal) VALUES (1, '".$diad."', '".$horariod."', '".$Idmdx."', '".$Iddhx."', '".$Idsal."')";

$retry_value2 = mysqli_query($db_connection,$insert_value);

$update_value = "UPDATE docentesh SET  Estado=2 WHERE Iddh='".$Iddhx."'";

$retry_value1 = mysqli_query($db_connection,$update_value);

$AA=$A+1;

$update_value = "UPDATE detallemd SET  Asignadas='".$AA."' WHERE Idmd='".$Idmdx."'";

$retry_value3 = mysqli_query($db_connection,$update_value);

$men="Agregó el Horario del Docente";

mysqli_free_result($r0);
mysqli_free_result($r2);
mysqli_free_result($r3);

}

}

}

}
//acción
}

//acción de borrar


if($acc==1)
{

$cuenta=0;

$r1=mysqli_query($db_connection, "SELECT d.Horas, d.Asignadas, d.Iddoc, d.Idmat, d.Idcic, d.Idmd, m.Materia, ca.Carrera, ca.Dia, ca.Idcar, s.Idsal FROM detallemd d, ciclos c, salones s, materias m, carreras ca WHERE d.Idcic= '".$Idcic."' && m.Idcar=ca.Idcar && d.Idmat=m.Idmat   && c.Estado=1 && d.Idcic=c.Idcic && s.Idcic=c.Idcic && s.Idsal= '".$Idsal."' && d.Asignadas = d.Horas ORDER BY d.Idmat");

if (mysqli_num_rows($r1)>0)
while ($row1 =mysqli_fetch_array($r1)){

 $Idmdx=$row1['Idmd'];
 $Iddocx=$row1['Iddoc'];
 $H=$row1['Horas'];
 $A=$row1['Asignadas'];
 $D=$row1['Dia'];


$men="mientras haya horas a asignar en el salón";

if($D==$lv)
{

$cuenta++;

$men="carrera dia".$Iddocx;
// horario libre del docente

$r2=mysqli_query($db_connection, "SELECT Iddh, Dia, Horario FROM docentesh WHERE Iddoc='".$Iddocx."' && Estado=2");

if(mysqli_num_rows($r2)>0)
while ($row2 =mysqli_fetch_array($r2)){
    $Iddhx=$row2['Iddh'];
   	$diad=$row2['Dia'];
    $horariod=$row2['Horario'];

// horario del salón detalleh 

$men="horario del salón";

$r3=mysqli_query($db_connection, "SELECT Dia, Horario FROM detalleh WHERE Dia= '".$diad."' && Horario= '".$horariod."' && Idsal='".$Idsal."' && Idmd='".$Idmdx."' && Iddh='".$Iddhx."'  ");

//si día está dentro del rango lv

if(mysqli_num_rows($r3)>0)
if($diad==$l || $diad==$ma || $diad==$mi || $diad==$j || $diad==$v )
{
$men="rango del día";
//asigna hora

$delete_value = "DELETE FROM detalleh  WHERE Idsal='".$Idsal."' && Idmd='".$Idmdx."' && Iddh='".$Iddhx."'";

$retry_value2 = mysqli_query($db_connection,$delete_value);

//alter table
$num=0;
$rn=mysqli_query($db_connection, "SELECT count(Idh) num FROM detalleh ");


while ($row =mysqli_fetch_array($rn))
    $num=$row['num'];

$num=$num+1;

$alter = "ALTER TABLE detalleh auto_increment='".$num."' ";

$retry_value = mysqli_query($db_connection,$alter);


$update_value = "UPDATE docentesh SET Estado=1 WHERE Iddh='".$Iddhx."'";

$retry_value1 = mysqli_query($db_connection,$update_value);

$AA=$A+1;

$update_value = "UPDATE detallemd SET Asignadas=0 WHERE Idmd='".$Idmdx."'";

$retry_value3 = mysqli_query($db_connection,$update_value);

$men="Borro el Horario del Docente";
}


}

}

}

}





header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');



mysqli_free_result($resultado);
mysqli_close($db_connection);
?>






