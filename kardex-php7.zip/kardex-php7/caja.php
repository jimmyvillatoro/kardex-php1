<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Caja Kardex</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Idusu= utf8_decode($_GET['Idusu']);
$Idesc= utf8_decode($_GET['Idesc']);$Idcar= utf8_decode($_GET['Idcar']);
$Idcic= utf8_decode($_GET['Idcic']);
$Idsal= utf8_decode($_GET['Idsal']);
$Idalu= utf8_decode($_GET['Idalu']);

$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres, Idesc, Foto FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row['Nombres'];
    $Idescl=$row['Idesc'];
     $foto=$row['Foto'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<SCRIPT language=JavaScript>

function tick() {
  var hours, minutes, seconds, ap;
  var intHours, intMinutes, intSeconds;
  var today;
  today = new Date();
  intHours = today.getHours();
  intMinutes = today.getMinutes();
  intSeconds = today.getSeconds();

  switch(intHours){
       case 0:
           intHours = 12;
           hours = intHours+":";
           ap = "A.M.";
           break;
       case 12:
           hours = intHours+":";
           ap = "P.M.";
           break;
       case 24:
           intHours = 12;
           hours = intHours + ":";
           ap = "A.M.";
           break;
       default:    
           if (intHours > 12)
           {
             intHours = intHours - 12;
             hours = intHours + ":";
             ap = "P.M.";
             break;
           }
           if(intHours < 12)
           {
             hours = intHours + ":";
             ap = "A.M.";
           }
    }       
       

  if (intMinutes < 10) {
     minutes = "0"+intMinutes+":";
  } else {
     minutes = intMinutes+":";
  }

  if (intSeconds < 10) {
     seconds = "0"+intSeconds+" ";
  } else {
     seconds = intSeconds+" ";
  } 

  timeString = hours+minutes+seconds+ap;
  Clock.innerHTML = timeString;
  window.setTimeout("tick();", 100);
}

window.onload = tick;
</SCRIPT>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Caja <span> Kardex</span></h1>
				<p>Area de Cobros de Colegiatura </p>
			</div>
			
			<div id="page" class="round">
			<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="caja.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>" title="" class="round active">Área de Caja</a></li>
<li><a href="pagos.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>" title="" class="round">Área de Pagos</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>


			<div id="wrapper2" class="round">
				<div id="sidebar" class="round">
						<h3>Alumnos</h3>
						<ul>
		   <li>Registro</li>
     <li>Actualizar</li>
     <li>Historial</li>
						</ul>


 <h3>Soporte</h3>
						<ul>
    <li>Soporte</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">

				<h2 align="center">	<a id=Clock style="FONT-SIZE: 40px; COLOR: GREEN; FONT-FAMILY: " class="current"></a></h2>

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);
 ?> </a></p>


<?php

$dir = 'dat/usuarios/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='right'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?>


<div id="wrapper2" class="round">			
<div id="sidebar2" class="round">
<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

if($Idesc<=0)
$Idesc=$Idescl;

$resultado1=mysqli_query($db_connection, "SELECT Idesc, Escuela FROM escuelas WHERE  Estado=1 && Idesc='".$Idesc."' ORDER BY Idesc  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
   $Idesc=$row1['Idesc'];
	  $Escuela=$row1['Escuela'];
?> 
<h3><a style="color:orange;">  <?php echo $Escuela; ?></a></h3>
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>			

<h3><a href="caja.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">Nuevo Recibo <img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/> </a></h3>

<h3>Buscar Alumno</h3>

<form action="pbusalu.php" method="POST" >
      <input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
      <input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
    
<div>
<div>
<input type="text" name="cor" class="form-control" placeholder="Correo, Matricula, Apellidos, Nombres" class="form-input" size="30" required>
<button type="submit"><img src="dat/ima/busca.png" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<?php
include 'dat/cdb/db.php';
$Idalu= utf8_decode($_GET['Idalu']);
$resultx=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Foto FROM alumnos WHERE Idalu = '".$Idalu."' ");

if (mysqli_num_rows($resultx)>0)
{

while ($rowx =mysqli_fetch_array($resultx)){
    $nom=$rowx['Nombres'];
    $ape=$rowx['Apellidos'];
    $foto=$rowx['Foto'];

$dir = 'dat/alumnos/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='right'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?>

<center>	<a style="FONT-SIZE: 30px; COLOR: GREEN; FONT-FAMILY: " class="current">Alumno: <?php echo $nom; ?> <?php echo $ape; ?> </a> </center>

<?php
}
}
mysqli_free_result($resultx);
mysqli_close($db_connection);
?>



<form action="caja.php" method="GET" >
      <input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
      <input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
    
<input type="hidden" name="Idalu"  value="<?php echo utf8_decode($_GET['Idalu']); ?>">

<input type="hidden" name="scar"  value="<?php echo utf8_decode($_GET['scar']); ?>">
<input type="hidden" name="scic"  value="<?php echo utf8_decode($_GET['scic']); ?>">
<input type="hidden" name="ssal"  value="<?php echo utf8_decode($_GET['ssal']); ?>">

<div class="row" >
<div class="col" >Carrera:
<select name="scar" onchange = "this.form.submit()">
<option selected="selected" value="0">Seleccionar</option>
<?php
include 'dat/cdb/db.php';
$scar = utf8_decode($_GET['scar']);

$Idesc = utf8_decode($_GET['Idesc']);
$resultado2=mysqli_query($db_connection, "SELECT Idcar, Carrera FROM carreras WHERE  Idesc='".$Idesc."' ORDER BY Idcar ");

if($scar>0)
{
$resultado2=mysqli_query($db_connection, "SELECT Idcar, Carrera FROM carreras WHERE Idcar='".$scar."' ");
}

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
   $scar=$row2['Idcar'];
	  $Carrera=$row2['Carrera'];

?> 
  <option value="<?php echo $scar; ?>"><?php echo $Carrera; ?></option>
<?php
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>			
</select>
<a style="color:orange;"> <?php echo $Carrera; ?> </a>
</div>
</div>
</form>


<form action="caja.php" method="GET" >
      <input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
      <input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
      
<input type="hidden" name="Idalu"  value="<?php echo utf8_decode($_GET['Idalu']); ?>">

<input type="hidden" name="scar"  value="<?php echo utf8_decode($_GET['scar']); ?>">
<input type="hidden" name="scic"  value="<?php echo utf8_decode($_GET['scic']); ?>">
<input type="hidden" name="ssal"  value="<?php echo utf8_decode($_GET['ssal']); ?>">

<div class="row" >
<div class="col" >Ciclo Escolar:
<select name="scic" onchange= "this.form.submit()" >
<option selected="selected" value="0">Seleccionar</option>

<?php
include 'dat/cdb/db.php';
$scar = utf8_decode($_GET['scar']);
$scic = utf8_decode($_GET['scic']);
$resultado3=mysqli_query($db_connection, "SELECT Idcic, Ciclo, Sistema FROM ciclos WHERE  Idcar='".$scar."' ORDER BY Idcic ");

if($scic>0)
{
$resultado3=mysqli_query($db_connection, "SELECT Idcic, Ciclo, Sistema FROM ciclos WHERE  Idcic='".$scic."' ORDER BY Idcic ");
}

if (mysqli_num_rows($resultado3)>0)
{			  
      while ($row3 =mysqli_fetch_array($resultado3)) 
	  {
   $scic=$row3['Idcic'];
	  $Ciclo=$row3['Ciclo'];
   $Sistema=$row3['Sistema'];

?> 

  <option value="<?php echo $scic; ?>"><?php echo $Ciclo; ?> - <?php echo $Sistema; ?></option>

<?php
      }
}
mysqli_free_result($resultado3);
mysqli_close($db_connection);
 ?>				
</select>
<a style="color:orange;"> <?php echo $Ciclo; ?> - <?php echo $Sistema; ?> </a>

</div>
</div>
</form>


<form action="caja.php" method="GET" >
      <input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
      <input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
<input type="hidden" name="Idalu"  value="<?php echo utf8_decode($_GET['Idalu']); ?>">

<input type="hidden" name="scar"  value="<?php echo utf8_decode($_GET['scar']); ?>">
<input type="hidden" name="scic"  value="<?php echo utf8_decode($_GET['scic']); ?>">
<input type="hidden" name="ssal"  value="<?php echo utf8_decode($_GET['ssal']); ?>">

<div class="row" >
<div class="col" >Salones:
<select name="ssal" onchange = "this.form.submit()">
<option selected="selected" value="0">Seleccionar</option>
<?php
include 'dat/cdb/db.php';
$ssal = utf8_decode($_GET['ssal']);
$scic = utf8_decode($_GET['scic']);
$resultado4=mysqli_query($db_connection, "SELECT Idsal, Turno, Grado, Grupo FROM salones WHERE  Idcic='".$scic."' ORDER BY Idsal ");

if($ssal>0)
{
$resultado4=mysqli_query($db_connection, "SELECT Idsal, Turno, Grado, Grupo FROM salones WHERE  Idsal='".$ssal."' ORDER BY Idsal ");
}


if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
   $ssal=$row4['Idsal'];
	  $Turno=$row4['Turno'];
   $Grado=$row4['Grado'];
   $Grupo=$row4['Grupo'];

$resultado5=mysqli_query($db_connection, "SELECT Costo FROM grados WHERE  Grado='".$Grado."' && Idcar='".$scar."' ");


if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5))
   $Costo=$row5['Costo'];
}
?>
  <option value="<?php echo $ssal; ?>"><?php echo $Turno; ?> - <?php echo $Grado; ?> - <?php echo $Grupo; ?> - <?php echo $Costo; ?></option>

<?php
      }
}

mysqli_free_result($resultado4);
mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>				
</select>
<a style="color:orange;"><?php echo $Turno; ?> - <?php echo $Grado; ?> - <?php echo $Grupo; ?> - <?php echo $Costo; ?> </a>

</div>
</div>
</form>


<h3>Datos del Recibo</h3>

<form action="pcaja.php" method="POST" >
      <input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
      <input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
<input type="hidden" name="Idalu"  value="<?php echo utf8_decode($_GET['Idalu']); ?>">
    
<input type="hidden" name="scar"  value="<?php echo utf8_decode($_GET['scar']); ?>">
<input type="hidden" name="scic"  value="<?php echo utf8_decode($_GET['scic']); ?>">
<input type="hidden" name="ssal"  value="<?php echo utf8_decode($_GET['ssal']); ?>">

<div>
<div>

<input type="text" name="fol" class="form-control" placeholder="Folio" class="form-input" size="5">

<input type="text" name="can" class="form-control" placeholder="Cantidad" class="form-input" size="5" value="1">

<select name="des">
<option selected="selected"  value="Colegiatura">Colegiatura</option>
<option value="Inscripción">Inscripción</option>
<option value="Uniforme">Uniforme</option>
<option value="Credencial">Credencial</option>
<option value="Otros varios">Otros varios</option>
</select>

<select name="mes">
<option selected="selected"  value="0">Seleccionar</option>
<option value="Enero">Enero</option>
<option value="Febrero">Febrero</option>
<option value="Marzo">Marzo</option>
<option value="Abril">Abril</option>
<option value="Mayo">Mayo</option>
<option value="Junio">Junio</option>
<option value="Julio">Julio</option>
<option value="Agosto">Agosto</option>
<option value="Septiembre">Septiembre</option>
<option value="Octubre">Octubre</option>
<option value="Noviembre">Noviembre</option>
<option value="Diciembre">Diciembre</option>
</select>

<input type="text" name="cos" class="form-control" placeholder="Costo" class="form-input" size="5" value="<?php echo $Costo; ?>" required>

<input type="text" name="desc" class="form-control" placeholder="Descuento" class="form-input" size="5" value="0" required>

<input type="text" name="rec" class="form-control" placeholder="Recargo" class="form-input" size="5" value="0" required>

<button type="submit"><img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<?php
include 'dat/cdb/db.php';
$Idalu = utf8_decode($_GET['Idalu']);

$resultado6=mysqli_query($db_connection, "SELECT Idcol, Folio, Cantidad, Descripcion, Mes, Grado, Costo, Descuento, Recargo, Importe, Iva, Total, Letras FROM colegiaturas WHERE  Estado=0 && Idalu='".$Idalu."' ");

if (mysqli_num_rows($resultado6)>0)
{			  
      while ($row6 =mysqli_fetch_array($resultado6)){
   $Idcol=$row6['Idcol'];
   $fol=$row6['Folio'];
   $can=$row6['Cantidad'];
   $des=$row6['Descripcion'];
   $mes=$row6['Mes'];
   $gra=$row6['Grado'];
   $cos=$row6['Costo'];
   $desc=$row6['Descuento'];
   $rec=$row6['Recargo'];
   $imp=$row6['Importe'];
   $iva=$row6['Iva'];
   $tot=$row6['Total'];
   $let=$row6['Letras'];
?>
</br><?php echo $fol; ?> - 
<?php echo $can; ?> - <?php echo $des; ?> - <?php echo $mes; ?> - <?php echo $gra; ?> - <?php echo $cos; ?> - <?php echo $desc; ?> - <?php echo $rec; ?>
</br>
<?php echo $imp; ?> - <?php echo $iva; ?> - <?php echo $tot; ?>
   
<button type="submit"><a href="pborcol.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idalu=<?php echo $Idalu; ?>&Idcol=<?php echo $Idcol; ?>"> <img src="dat/ima/borra.png" alt="" width="40" height="40"  class="round"/> </a></button>

</br>
<?php echo $let; ?>
</br>
<?php
      }
}
mysqli_free_result($resultado6);
mysqli_close($db_connection);
 ?>				

<form action="imprimir.php" method="POST" >

<input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
<input type="hidden" name="Idalu" value="<?php echo utf8_decode($_GET['Idalu']); ?>">
    
<div>
<div>
<button type="submit"><img src="dat/ima/imp.png" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<h3>Agregar Alumno</h3>					
<ul>
<li align="center">
<a href="regaluc.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>"> <img src="dat/ima/user.jpeg" alt="" width="200" height="150"  class="round" /> </a></li>

<li align="center"><a href="regaluc.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">Agregar alumno</a></li>					
</ul>

<h3>Actualizar tú perfil</h3>					
<ul>
<li align="center"><a href="actusu2.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">
<img src="dat/ima/tipo.png" alt="" width="250" height="200" class="round" /></a> 
</li>
<li align="center"><a href="actusu2.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">Actualiza tú perfil</a></li>				

<li align="center"><a href="cargaru2.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">Asignar Foto <img src="dat/ima/next.jpeg" alt="" width="40" height="40"  class="round"/></a></li>		
	
</ul>

<div id="splash" align="center">
<img src="dat/ima/kardexb.png" alt="" width="600" height="300" class="round" align="center" />

<!-- End Sidebar -->
</div>
</div>
					<!-- End Content -->
					</div>
					<div style="clear: both"></div>
				<!-- End Wrapper 2 -->
				</div>
			<!-- End Page -->
			</div>
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.
</div>

</body>
</html>
