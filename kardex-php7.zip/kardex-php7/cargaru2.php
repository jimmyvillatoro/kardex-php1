<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Foto de Usuario</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />

<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idsal = utf8_decode($_GET['Idsal']);


$men = utf8_decode($_GET['men']);


$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$men = $_REQUEST['men'];

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios WHERE Idusu = '".$Idusu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row['Nombres'];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Envíar Foto de <span>Usuario</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>



<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="caja.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>" title="" class="round active">Atrás</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>



			</ul>	

		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	



<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>


<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);

 ?> </a></p>
		

<ul>

<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idusu = $_REQUEST['Idusu'];


$resultado2=mysqli_query($db_connection, "SELECT Foto FROM usuarios WHERE  Idusu='".$Idusu."' ");



if (mysqli_num_rows($resultado2)>0)

{			  

      while ($row2 =mysqli_fetch_array($resultado2)) 

	  {

   $foto=$row2['Foto'];


      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>

 <?php

$dir = 'dat/usuarios/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='center'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?>


				


<?php

$archivo = $directorio.basename($_FILES['subir_archivo']['name']);
$l = strlen($archivo);
if($l <= 0){
?>

<h1 align="center">Envíar Foto</h1>

</br>
<form enctype="multipart/form-data" action="cargaru2.php" method="POST">


<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">

<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>"> 
<input type="hidden" name="men" value="<?php echo $men="Foto enviada"; ?>"> 


    <input type="hidden" name="MAX_FILE_SIZE" value="512000" />

   <p><img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/><input name="subir_archivo" type="file" /></p>


<button type="submit" value="Enviar Archivo"><img src="dat/ima/foto.png" alt="" width="40" height="40"  class="round"/></button>

</form>

<?php
}
?>

</br>
</br>
<div class="main">
<h1 align="center">Archivo en proceso</h1>
<?php

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];

$archivo = $directorio.basename($_FILES['subir_archivo']['name']);
$l = strlen($archivo);

$directorio = 'dat/usuarios/';
$subir_archivo = $directorio.basename($_FILES['subir_archivo']['name']);

echo "<div>";
if (move_uploaded_file($_FILES['subir_archivo']['tmp_name'], $subir_archivo)) {
      echo "El archivo es válido y se cargó correctamente.<br><br>";
	   echo"<a href='".$subir_archivo."' target='_blank'><img src='".$subir_archivo."' width='150'></a>";
    } else {
       echo "La subida ha fallado";
    }
    echo "</div>";

if($l > 0){

include 'dat/cdb/db.php';

$update_value ="UPDATE usuarios SET Foto='".$archivo."'  WHERE Idusu='".$Idusu."' ";

$retry_value = mysqli_query($db_connection,$update_value);


mysqli_close($db_connection);
}
?>
<br>
<div style="border:1px solid #000000; text-transform:uppercase">  
</div>
</div>
					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>


</html>

