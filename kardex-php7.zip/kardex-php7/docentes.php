<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Area del Docente</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';



$Iddoc = utf8_decode($_GET['Iddoc']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idsal = utf8_decode($_GET['Idsal']);



$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Idesc, Foto FROM docentes  WHERE Iddoc = '".$Iddoc."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row['Nombres'];

$Apellidos=$row['Apellidos'];
    $Idescl=$row['Idesc'];
    $foto=$row['Foto'];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Control <span> Kardex</span></h1>

				<p>Area del docente</p>

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>" title="" class="round active">Área del Docente</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>				

						

			
 <h3>Soporte</h3>

						<ul>

			 <li>Ticket</li>

    <li>Soporte</li>

						</ul>

					

					<!-- End Sidebar -->				

					</div>

					

					<div id="content" class="round">

					



<p>Docente:<a style="color:orange;"> <?php echo $Nombres; ?> <?php echo $Apellidos; ?></a></p>


 <?php

$dir = 'dat/docentes/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='right'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?>



<div id="wrapper2" class="round">					

<div id="sidebar2" class="round">					

<h3>Lista de Institutos</h3>					

<ul>

<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);



if($Idesc<0)
$Idesc=$Idescl;



$resultado1=mysqli_query($db_connection, "SELECT Idesc, Escuela FROM escuelas WHERE  Estado=1 && Idesc='".$Idesc."' ORDER BY Idesc  ");



if (mysqli_num_rows($resultado1)>0)

{			  

      while ($row1 =mysqli_fetch_array($resultado1)) 

	  {

   $Idesc1=$row1['Idesc'];

	  $Escuela=$row1['Escuela'];



?> 

<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc1; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a> <?php echo $Escuela; ?> </li>

<?php

      }

}

mysqli_free_result($resultado1);

mysqli_close($db_connection);

 ?>				

</ul>



			

<h3>Lista de Carreras</h3>

<ul>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);





$resultado2=mysqli_query($db_connection, "SELECT Idcar, Carrera FROM carreras WHERE  Idesc='".$Idesc."' ORDER BY Idcar ");



if (mysqli_num_rows($resultado2)>0)

{			  

      while ($row2 =mysqli_fetch_array($resultado2)) 

	  {

   $Idcar2=$row2['Idcar'];

	  $Carrera=$row2['Carrera'];



?> 

<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar2; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a> <?php echo $Carrera; ?>   </li>

<?php

      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>





<h3>Lista de Ciclos</h3>

<ul>



<?php

include 'dat/cdb/db.php';



$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);





$resultado3=mysqli_query($db_connection, "SELECT Idcic, Ciclo FROM ciclos WHERE  Idcar='".$Idcar."' ORDER BY Idcic ");



if (mysqli_num_rows($resultado3)>0)

{			  

      while ($row3 =mysqli_fetch_array($resultado3)) 

	  {

   $Idcic3=$row3['Idcic'];

	  $Ciclo=$row3['Ciclo'];



?> 

<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic3; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a><?php echo $Ciclo; ?>  Horario-doc<a href="reghordoc.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic3; ?>"> <img src="dat/ima/mas.jpg" alt="" width="40" height="40"  class="round"/> </a>    </li>

<?php

      }

}

mysqli_free_result($resultado3);

mysqli_close($db_connection);

 ?>				



</ul>



<h3>Lista de Salones</h3>

<ul>



<?php

include 'dat/cdb/db.php';



$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);





$resultado4=mysqli_query($db_connection, "SELECT Idsal, Turno, Grado, Grupo FROM salones WHERE  Idcic='".$Idcic."' ORDER BY Idsal ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

   $Idsal4=$row4['Idsal'];

	  $Turno=$row4['Turno'];

   $Grado=$row4['Grado'];

   $Grupo=$row4['Grupo'];



?> 



<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcic=<?php echo $Idcic; ?>&Idcar=<?php echo $Idcar; ?>&Idsal=<?php echo $Idsal4; ?>"><img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a><?php echo $Turno; ?> <?php echo $Grado; ?> <?php echo $Grupo; ?>  Calificaciones<a href="regcal.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal4; ?>"> <img src="dat/ima/mas.jpg" alt="" width="40" height="40"  class="round"/> </a>  </li>


 <li><img src="dat/ima/mas.jpg" alt="" width="40" height="40"  class="round"/>Lista del salón<a href="implis.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal4; ?>"> <img src="dat/ima/imp.png" alt="" width="40" height="40"  class="round"/> </a>  </li>

 <li><img src="dat/ima/mas.jpg" alt="" width="40" height="40"  class="round"/>Horario del salón<a href="imphor.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal4; ?>"> <img src="dat/ima/imp.png" alt="" width="40" height="40"  class="round"/> </a>  </li>


 <li><img src="dat/ima/mas.jpg" alt="" width="40" height="40"  class="round"/>Lista del salón para calificar a mano<a href="impliscal.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal4; ?>"> <img src="dat/ima/imp.png" alt="" width="40" height="40"  class="round"/> </a>  </li>




<?php

      }

}

mysqli_free_result($resultado4);

mysqli_close($db_connection);

 ?>				

</ul>

<h3>Consultas Generales</h3>					

<ul>

<li> Ver Horarios<a href="verhorad.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcic=<?php echo $Idcic; ?>&Idcar=<?php echo $Idcar; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/> </a></li>

<li> Ver Materias<a href="vermatad.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcic=<?php echo $Idcic; ?>&Idcar=<?php echo $Idcar; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/> </a></li>

<li> Ver Cobros<a href="verpagad.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcic=<?php echo $Idcic; ?>&Idcar=<?php echo $Idcar; ?>&Idsal=<?php echo $Idsal; ?>"> <img src="dat/ima/buscar.png" alt="" width="40" height="40"  class="round"/> </a></li>

</ul>

<h3>Control de tú perfil</h3>					

<ul>

<li align="center">

<a href="actdoc.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>"> <img src="dat/ima/tipo.png" alt="" width="300" height="200"  class="round" /> </a></li>

<li align="center"><a href="actdoc.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>">Actualiza tú perfil</a></li>				

	<li align="center"><a href="cargard.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>">Asignar Foto <img src="dat/ima/next.jpeg" alt="" width="40" height="40"  class="round"/></a></li>				

</ul>





<!-- End Sidebar -->

</div>



    </div>

					

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

	<div id="footer">

			

<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>

</body>

	



</html>








