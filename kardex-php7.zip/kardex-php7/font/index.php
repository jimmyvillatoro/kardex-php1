<?php
$men="Acceso denegado";
header('Location: ../sesion.php?men='.$men.'');
?>
