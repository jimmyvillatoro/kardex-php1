<?php
include 'dat/cdb/db.php';

$Idalu = $_REQUEST['Idalu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idmat = $_REQUEST['Idmat'];
$Idgra = $_REQUEST['Idgra'];
$Idsal = $_REQUEST['Idsal'];
$Iddoc = $_REQUEST['Iddoc'];
$Idcal = $_REQUEST['Idcal'];

$tra = $_REQUEST['tra'];
$tar = $_REQUEST['tar'];
$exa = $_REQUEST['exa'];
$tot = $tra+$tar+$exa;
$fal = $_REQUEST['fal'];
$not = $_REQUEST['not'];


date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());

$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Idalu='".$Idalu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$update_value ="UPDATE calificaciones SET  Fecha='".$date."', Hora='".$time."', Tarea='".$tar."', Trabajo='".$tra."', Examen='".$exa."', Total='".$tot."', Faltas='".$fal."', Nota='".$not."'  WHERE Idcal='".$Idcal."' ";

$retry_value = mysqli_query($db_connection,$update_value);

mysqli_free_result($retry_value);

$men="Calificación actualizada";


header('Location: regcal.php?Idalu='.$Idalu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');

 } else {


$men="Seleccionar al alumno";

header('Location: regcal.php?Idalu='.$Idalu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');



}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
