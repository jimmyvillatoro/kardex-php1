<?php
include 'dat/cdb/db.php';

$car = $_REQUEST['car'];
$rev = $_REQUEST['rev'];
$tie = $_REQUEST['tie'];

$Idesc = $_REQUEST['Idesc'];
$Idusu = $_REQUEST['Idusu'];
$Idcar = $_REQUEST['Idcar'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$update_value ="UPDATE carreras SET Carrera='".$car."', Revoe='".$rev."', Tiempo='".$tie."' WHERE Idcar='".$Idcar."' ";

$retry_value = mysqli_query($db_connection,$update_value);

$men="Carrera actualizada";


header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
