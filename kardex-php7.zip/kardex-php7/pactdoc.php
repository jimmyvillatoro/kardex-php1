<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];


$Idesc = $_REQUEST['Idesc'];
$Iddoc = $_REQUEST['Iddoc'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$update_value ="UPDATE docentes SET Nombres='".$nom."', Apellidos='".$ape."', Correo='".$cor."', Movil='".$mov."', Pass='".$pas."' WHERE Iddoc='".$Iddoc."' ";

$retry_value = mysqli_query($db_connection,$update_value);

$men="Docente actualizado";


header('Location: docentes.php?Iddoc='.$Iddoc.'&Idesc='.$Idesc.'&men='.$men.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
