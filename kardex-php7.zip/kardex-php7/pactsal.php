<?php



include 'dat/cdb/db.php';





$tur = $_REQUEST['tur'];

$gra = $_REQUEST['gra'];
$gram = $_REQUEST['gra'];

$gru = $_REQUEST['gru'];

$cos = $_REQUEST['cos'];





$Idesc = $_REQUEST['Idesc'];

$Idusu = $_REQUEST['Idusu'];

$Idcar = $_REQUEST['Idcar'];

$Idcic = $_REQUEST['Idcic'];

$Idsal = $_REQUEST['Idsal'];

$Idgra = $_REQUEST['Idgra'];





if($tur==1)

$tur=

"Matutino";

if($tur==2)

$tur=

"Vespertino";

if($tur==3)

$tur=

"Mixto";





if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";





if($gru==1)

$gru=

"A";

if($gru==2)

$gru=

"B";

if($gru==3)

$gru=

"C";

if($gru==4)

$gru=

"D";

if($gru==5)

$gru=

"E";

if($gru==6)

$gru=

"F";

if($gru==7)

$gru=

"G";

if($gru==8)

$gru=

"H";

if($gru==9)

$gru=

"I";

if($gru==10)

$gru=

"J";



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());




$result=mysqli_query($db_connection, "SELECT Idgra FROM grados WHERE Grado='".$gra."' && Idcar='".$Idcar."' ");



if (mysqli_num_rows($result)<=0)
{

$insert_value = "INSERT INTO grados (Grado, Costo, Idgram, Idcar) VALUES ('".$gra."', '".$cos."', '".$gram."', '".$Idcar."')";


$retry_value2 = mysqli_query($db_connection,$insert_value);

$result=mysqli_query($db_connection, "SELECT Idgra FROM grados WHERE Grado='".$gra."' && Idcar='".$Idcar."' ");

while ($row =mysqli_fetch_array($result)) 
   	 $Idgra=$row['Idgra'];


}


if (mysqli_num_rows($result)>0)
{
while ($row =mysqli_fetch_array($result)) 
   	 $Idgra=$row['Idgra'];

$update_value = "UPDATE grados SET Costo='".$cos."' WHERE Idgra='".$Idgra."'";

$retry_value3 = mysqli_query($db_connection,$update_value);
}


$update_value ="UPDATE salones SET Turno='".$tur."', Grado='".$gra."', Grupo='".$gru."', Idgra='".$Idgra."' WHERE Idsal='".$Idsal."' ";

$retry_value = mysqli_query($db_connection,$update_value);



$men="Actualizó el salon";



header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');



mysqli_free_result($retry_value);



mysqli_close($db_connection);

?>










