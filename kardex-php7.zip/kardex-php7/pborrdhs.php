<?php



include 'dat/cdb/db.php';



$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];

$Idcar = $_REQUEST['Idcar'];

$Idcic = $_REQUEST['Idcic'];

$Idsal = $_REQUEST['Idsal'];

$Idmat = $_REQUEST['Idmat'];

$Idgra = $_REQUEST['Idgra'];

$Iddoc = $_REQUEST['Iddoc'];

$Idmd  = $_REQUEST['Idmd'];

$Idh  = $_REQUEST['Idh'];


$nh = $_REQUEST['nh'];
$gra = $_REQUEST['gra'];
$hor = $_REQUEST['hor'];// Iddh




$resultado=mysqli_query($db_connection, "SELECT Iddh FROM detalleh WHERE  Idh='".$Idh."' ");



if (mysqli_num_rows($resultado)>0)

{



while ($rowx =mysqli_fetch_array($resultado))

   	 $Iddh=$rowx['Iddh'];





$update_value = "UPDATE docentesh SET Estado=1 WHERE Iddh='".$Iddh."' && Iddoc= '".$Iddoc."' && Estado>0";



$retry_value1 = mysqli_query($db_connection,$update_value);



$result=mysqli_query($db_connection, "SELECT Idmd, Horas, Asignadas FROM detallemd WHERE Iddoc= '".$Iddoc."' && Idmat= '".$Idmat."' && Idcic= '".$Idcic."'");



if (mysqli_num_rows($result)>0)

while ($rowx =mysqli_fetch_array($result))

{

   	 $Idmd=$rowx['Idmd'];

    $H=$rowx['Horas'];

    $A=$rowx['Asignadas'];

}



$AA=$A-1; //act de h asignadas



$update_value = "UPDATE detallemd SET  Asignadas='".$AA."' WHERE Idmd='".$Idmd."'";



$retry_value2 = mysqli_query($db_connection,$update_value);



$delete_value = "DELETE FROM detalleh WHERE Idh='".$Idh."' && Horas=1 ";



$retry_value3 = mysqli_query($db_connection,$delete_value);







$men="Borró el horario del docente";



header('Location: regrdhs.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');


mysqli_free_result($retry_value1);

mysqli_free_result($retry_value2);

mysqli_free_result($retry_value3);

mysqli_free_result($result);





 } else {



$men="Seleccionar el horario";




header('Location: regrdhs.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');

}



mysqli_free_result($resultado);

mysqli_close($db_connection);

?>








