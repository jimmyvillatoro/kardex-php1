<?php

include 'dat/cdb/db.php';

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idmat = $_REQUEST['Idmat'];
$Idgra = $_REQUEST['Idgra'];
$Iddoc = $_REQUEST['Iddoc'];
$Idmd  = $_REQUEST['Idmd'];


$resultado=mysqli_query($db_connection, "SELECT Idmd FROM detallemd WHERE Idmd= '".$Idmd."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$delete_value = "DELETE FROM detallemd WHERE Idmd='".$Idmd."' && Asignadas=0 ";

$retry_value = mysqli_query($db_connection,$delete_value);

$men="Borró la materia del docente";


header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

 } else {


$men="Seleccionar la materia o el docente";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
