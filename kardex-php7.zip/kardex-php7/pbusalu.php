<?php

include 'dat/cdb/db.php';

$cor = $_REQUEST['cor'];
$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];

$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Correo = '".$cor."' ");

$c=0;

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Idalu=$row['Idalu'];
$c++;
}

$men="Alumno consultado por Correo";
header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&men='.$men.'');
}


$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Matricula = '".$cor."' ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Idalu=$row['Idalu'];
$c++;
}

$men="Alumno consultado por Matricula";
header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&men='.$men.'');
}


$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Apellidos = '".$cor."' ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Idalu=$row['Idalu'];
$c++;
}

$men="Alumno consultado por Apellido";
header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&men='.$men.'');
}



$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Nombres = '".$cor."' ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Idalu=$row['Idalu'];
$c++;
}

$men="Alumno consultado por Nombres";
header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&men='.$men.'');
}

if (mysqli_num_rows($resultado)<=0 && $c==0)
{
$men="No se encuentra";

header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&men='.$men.'');
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>






