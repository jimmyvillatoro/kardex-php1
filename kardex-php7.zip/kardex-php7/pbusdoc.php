<?php

include 'dat/cdb/db.php';

$cor = $_REQUEST['cor'];
$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];

$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Correo = '".$cor."' ");

$c=0;

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Iddoc=$row['Iddoc'];
$c++;
}

$men="Docente consultado por Correo";
header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&men='.$men.'');
}


$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Movil = '".$cor."' ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Iddoc=$row['Iddoc'];
$c++;
}
$men="Docente consultado por Movil";
header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&men='.$men.'');
}


$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Apellidos = '".$cor."' ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Iddoc=$row['Iddoc'];
$c++;
}

$men="Docente consultado por Apellido";
header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&men='.$men.'');
}



$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Nombres = '".$cor."' ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Iddoc=$row['Iddoc'];
$c++;
}

$men="Docente consultado por Nombres";
header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&men='.$men.'');
}


if (mysqli_num_rows($resultado)<=0 && $c==0)
{

$men="No se encuentra";

header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&men='.$men.'');
}



mysqli_free_result($resultado);
mysqli_close($db_connection);
?>



