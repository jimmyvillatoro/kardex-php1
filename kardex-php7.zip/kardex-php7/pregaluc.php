<?php



include 'dat/cdb/db.php';





$mat = $_REQUEST['mat'];

$nom = $_REQUEST['nom'];

$ape = $_REQUEST['ape'];

$mov = $_REQUEST['mov'];

$cor = $_REQUEST['cor'];

$pas = $_REQUEST['pas'];



$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());





if($Idesc>0)

{



$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Correo = '".$cor."' ");

 



if (mysqli_num_rows($resultado)>0)

{



while ($row =mysqli_fetch_array($resultado))

   	 $Idalu=$row['Idalu'];

   



header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'');

 } else {





$insert_value = "INSERT INTO alumnos (Matricula, Nombres, Apellidos, Correo, Movil, Pass, Fecha, Idesc, Estado) VALUES ('".$mat."', '".$nom."',  '".$ape."',  '".$cor."',  '".$mov."', '".$pas."', '".$date."', '".$Idesc."', 1)";



$retry_value = mysqli_query($db_connection,$insert_value);





$cuerpo='Nombre: '. $nom.'  Movil: '.$mov.'  Correo: '.$cor;



mail('soporte@yaprendo.com','Un Alumno ',$cuerpo,'Equipo Kardex');



$result=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Nombres = '".$nom."' ");



while ($row1 =mysqli_fetch_array($result)) {

   	 $Idalu=$row1['Idalu'];

   }









$men="Agregó al alumno";





header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&men='.$men.'');



}



mysqli_free_result($retry_value);

mysqli_free_result($resultado);

mysqli_free_result($result);

mysqli_close($db_connection);



}else {



$men="Seleccionar o Agregar el Instituto";



header('Location: regaluc.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');



}

?>


