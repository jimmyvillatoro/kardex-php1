<?php

include 'dat/cdb/db.php';

$car = $_REQUEST['car'];
$rev = $_REQUEST['rev'];
$tie = $_REQUEST['tie'];


$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


if($Idesc>0)
{

$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO carreras (Carrera, Revoe, Tiempo, Idesc) VALUES ('".$car."', '".$rev."', '".$tie."', '".$Idesc."')";

$retry_value = mysqli_query($db_connection,$insert_value);


$result1=mysqli_query($db_connection, "SELECT Idcar FROM  carreras WHERE Carrera = '".$car."' ");


while ($row1 =mysqli_fetch_array($result1)) {
   	 $Idcar=$row1['Idcar'];
   }






$men="Agregó la carrera";


header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');


 } else {


$men="No tiene permiso";


header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');
}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_free_result($result1);
mysqli_close($db_connection);

}else {

$men="Seleccionar o Agregar primero el Instituto";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');

}

?>
