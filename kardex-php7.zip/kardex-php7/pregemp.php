<?php

include 'dat/cdb/db.php';

$emp = $_REQUEST['emp'];
$ubi = $_REQUEST['ubi'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$empr = $_REQUEST['empr'];

$Idusu = $_REQUEST['Idusu'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO empresas (Empresa, Ubicacion, Correo, Movil, Empresario, Fecha, Estado) VALUES ('".$emp."', '".$ubi."', '".$cor."', '".$mov."', '".$empr."', '".$date."',1)";

$retry_value = mysqli_query($db_connection,$insert_value);


$result1=mysqli_query($db_connection, "SELECT Idemp FROM empresas WHERE Empresa = '".$emp."' ");


while ($row1 =mysqli_fetch_array($result1)) {
   	 $Idemp=$row1['Idemp'];
   }

$update_value ="UPDATE usuarios SET Idemp='".$Idemp."' WHERE Idusu='".$Idusu."' ";

	$retry_value = mysqli_query($db_connection,$update_value);

$result2=mysqli_query($db_connection, "SELECT Nombres, Correo FROM usuarios WHERE Idusu = '".$Idusu."' ");


while ($row2 =mysqli_fetch_array($result2)) {
   	 $Nombres=$row2['Nombres'];
    $Correo2=$row2['Correo'];
   }


$cuerpo='Nombre de la granja: '. $esc.'  Móvil: '.$mov.' Correo: '.$cor.' Empresario: '.$empr.' Idemp: '.$Idemp.' Usuario: '.$Idusu.' Nombre: '.$Nombres.' Correo del usuario: '.$Correo2;

$men='Hola '.$Nombres.',Tu granja   '.$emp.' fue creado exitosamente, ahora envía el logotipo en formato jpg, al correo: soporte@yaprendo.com para que aparezca en tus recibos de colegiaturas, respetuosamente Equipo Incubo';

mail('soporte@yaprendo.com','Un Instituto->',$cuerpo,$men); 


header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'');


 } else {

header('Location: index.php?nom='.$nom.'&mov='.$mov.'&cor='.$cor.'');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_free_result($result1);
mysqli_free_result($result2);
mysqli_close($db_connection);
?>
