<?php



include 'dat/cdb/db.php';



$esc = $_REQUEST['esc'];

$ubi = $_REQUEST['ubi'];

$tel = $_REQUEST['tel'];

$cor = $_REQUEST['cor'];

$fir = $_REQUEST['fir'];

$iva = $_REQUEST['iva'];

$rec = $_REQUEST['rec'];

$rev = $_REQUEST['rev'];


$Idusu = $_REQUEST['Idusu'];



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());





$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");

 



if (mysqli_num_rows($resultado)>0)

{



$insert_value = "INSERT INTO escuelas (Escuela, Ubicacion, Correo, Telefono, Rector, Revoe, Firma, Iva, Fecha, Estado) VALUES ('".$esc."', '".$ubi."', '".$cor."', '".$tel."', '".$rec."', '".$rev."', '".$fir."', '".$iva."', '".$date."',1)";



$retry_value = mysqli_query($db_connection,$insert_value);





$result1=mysqli_query($db_connection, "SELECT Idesc FROM escuelas WHERE Escuela = '".$esc."' ");





while ($row1 =mysqli_fetch_array($result1)) {

   	 $Idesc=$row1['Idesc'];

   }



$update_value ="UPDATE usuarios SET Idesc='".$Idesc."' WHERE Idusu='".$Idusu."' ";



	$retry_value = mysqli_query($db_connection,$update_value);



$result2=mysqli_query($db_connection, "SELECT Nombres, Correo FROM usuarios WHERE Idusu = '".$Idusu."' ");





while ($row2 =mysqli_fetch_array($result2)) {

   	 $Nombres=$row2['Nombres'];

    $Correo2=$row2['Correo'];

   }





$cuerpo='Nombre del Instituto: '. $esc.'  Teléfono: '.$tel.' Correo: '.$cor.' Rectoría: '.$rec.' Idesc: '.$Idesc.' Usuario: '.$Idusu.' Nombre: '.$Nombres.' Correo del usuario: '.$Correo2;



$men='Hola '.$Nombres.',Tu instituto   '.$esc.' fue creado exitosamente, ahora espera nuestro correo: soporte@yaprendo.com para confirmar la activación, respetuosamente Equipo Kardex';



mail('soporte@yaprendo.com','Un Instituto->',$cuerpo,$men); 



$men="Agregó al Instituto";




header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&men='.$men.'');




 } else {







$men="Su usuario no tiene acceso";



header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'');



}



mysqli_free_result($retry_value);

mysqli_free_result($resultado);

mysqli_free_result($result1);

mysqli_free_result($result2);

mysqli_close($db_connection);

?>


