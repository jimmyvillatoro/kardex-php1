<?php

include 'dat/cdb/db.php';

$dia = $_REQUEST['dia'];
$Ideh = $_REQUEST['hor'];
$est = $_REQUEST['est'];

$Iddoc = $_REQUEST['Iddoc'];
$Idesc = $_REQUEST['Idesc'];
$Idcic = $_REQUEST['Idcic'];


$result=mysqli_query($db_connection, "SELECT  Horario FROM escuelash WHERE Ideh='".$Ideh."' ");



if(mysqli_num_rows($result)>0){			  
while ($rowx =mysqli_fetch_array($result))
     $hor=$rowx['Horario'];
}

mysqli_free_result($result);

$resultado=mysqli_query($db_connection, "SELECT Iddh FROM docentesh WHERE Dia='".$dia."' && Horario='".$hor."' && Iddoc='".$Iddoc."' ");


if(mysqli_num_rows($resultado)<=0)
{

$insert_value = "INSERT INTO docentesh (Dia, Horario, Estado, Ideh, Iddoc, Idcic) VALUES ('".$dia."', '".$hor."', '".$est."', '".$Ideh."', '".$Iddoc."', '".$Idcic."')";

$retry_value = mysqli_query($db_connection,$insert_value);

 }


$men="Agregó el Horario";

header('Location: reghordoc.php?Iddoc='.$Iddoc.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&men='.$men.'');

mysqli_free_result($resultado);

mysqli_close($db_connection);
?>