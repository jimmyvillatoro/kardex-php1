<?php

include 'dat/cdb/db.php';


$nh = $_REQUEST['nh'];


$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idmat = $_REQUEST['Idmat'];
$Idgra = $_REQUEST['Idgra'];
$Iddoc = $_REQUEST['Iddoc'];


$resultado=mysqli_query($db_connection, "SELECT Idesc FROM escuelas WHERE Idesc= '".$Idesc."' ");


if (mysqli_num_rows($resultado)>0)
{


$resultado=mysqli_query($db_connection, "SELECT Idcic FROM ciclos WHERE Idcic= '".$Idcic."' ");


if (mysqli_num_rows($resultado)>0)
{

$resultado=mysqli_query($db_connection, "SELECT Idmat FROM materias WHERE Idmat= '".$Idmat."' ");


if (mysqli_num_rows($resultado)>0)
{

$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Iddoc= '".$Iddoc."' ");


if (mysqli_num_rows($resultado)>0)
{


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO detallemd (Horas, Asignadas, Iddoc, Idmat, Idcic) VALUES ('".$nh."', 0, '".$Iddoc."', '".$Idmat."', '".$Idcic."')";

$retry_value = mysqli_query($db_connection,$insert_value);

$men="Agregó la Materia al Docente";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

 } else {

$men="Acceder nuevamnete";
header('Location: sesion.php?men='.$men.'');
}


 } else {


$men="Seleccionar al docente";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}

 } else {


$men="Seleccionar la materia";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}


 } else {


$men="Seleccionar el ciclo";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}


 } else {


$men="Seleccionar la escuela";

header('Location: usuarios.php?Idusu='.$Idusu.'&men='.$men.'');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>



