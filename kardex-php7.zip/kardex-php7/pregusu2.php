<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


if($Idesc>0)
{

$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu = '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO usuarios (Nombres, Apellidos, Correo, Movil, Pass, Idesc, Estado) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."', '".$Idesc."',2)";

$retry_value = mysqli_query($db_connection,$insert_value);

$men="Agregó el Usuario";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&men='.$men.'');



 } else {

header('Location: index.php?nom='.$nom.'& mov='.$mov.'&cor='.$cor.'');
}

mysqli_free_result($retry_value);
mysqli_close($db_connection);

}else {

$men="Seleccionar o Agregar el Instituto";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');

}
?>
