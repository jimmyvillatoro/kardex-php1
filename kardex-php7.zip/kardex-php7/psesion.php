<?php
include 'dat/cdb/db.php';

$cor = $_GET['cor'];
$pas = $_GET['pas'];

$resultado=mysqli_query($db_connection, "SELECT Idusu, Estado, Idesc FROM usuarios  WHERE Correo = '".$cor."' && Pass= '".$pas."' ");


session_start(); 


$cuenta=0;
$men="Datos incorrectos";


while ($row =mysqli_fetch_array($resultado)) {
   	$Idusu=$row['Idusu'];
	   $Estado=$row['Estado'];
    $Idesc=$row['Idesc'];
$cuenta++;

   }



$_SESSION['Idusu']=$Idusu;

//sistema de control escolar

	if($Estado==1)
    header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'');

	//sistema de caja

	if($Estado==2)
    header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'');



if($cuenta==0)//docentes

{
$resultado=mysqli_query($db_connection, "SELECT Iddoc, Estado, Idesc FROM docentes  WHERE Correo = '".$cor."' && Pass= '".$pas."' ");

$cuenta=0;
while ($row =mysqli_fetch_array($resultado)) {
   	$Iddoc=$row['Iddoc'];
	   $Estado=$row['Estado'];
    $Idesc=$row['Idesc'];
$cuenta++;
   }


$_SESSION['Iddoc']=$Iddoc;
 //sistema de docentes

	if($Estado==1)
 header('Location: docentes.php?Iddoc='.$Iddoc.'&Idesc='.$Idesc.'');

}



if($cuenta==0)//alumnos
{
$resultado=mysqli_query($db_connection, "SELECT Idalu, Estado, Idesc, Idcar, Idcic, Idsal FROM alumnos  WHERE Correo = '".$cor."' && Pass= '".$pas."' ");

$cuenta=0;
while ($row =mysqli_fetch_array($resultado)) {
   	$Idalu=$row['Idalu'];
	    $Estado=$row['Estado'];
    $Idesc=$row['Idesc'];
    $Idcar=$row['Idcar'];
    $Idcic=$row['Idcic'];
    $Idsal=$row['Idsal'];
$cuenta++; 
   }


$_SESSION['Idalu']=$Idalu;
 //sistema de docentes

	if($Estado==1)
 header('Location: alumnos.php?Idalu='.$Idalu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'');

}


if($cuenta==0)//salida
header('Location: sesion.php?men='.$men.'');


mysqli_free_result($resultado);
mysqli_close($db_connection);

?>




