<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Docentes</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idmat = utf8_decode($_GET['Idmat']);
$Idsal = utf8_decode($_GET['Idsal']);
$Idgra = utf8_decode($_GET['Idgra']);
$Iddoc = utf8_decode($_GET['Iddoc']);

$men = utf8_decode($_GET['men']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row['Nombres'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Registro</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				

				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>

	<div id="splash" align="center">
<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />
				</div>
	
<h3>Registro de Docente</h3>
						<ul>
<li> 



        <p>
            <form action="pregdoc.php" method="POST">
                <p align="justify"> Se parte del Equipo hoy</p>


<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>"> 


<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>"> 

                <div>
                    <div>

                        <input type="text" name="nom" class="form-control" placeholder="Nombres" class="form-input"
                            required>
                    </div>
                    <div>
                        <input type="text" name="ape" class="form-control" placeholder="Apellidos"
                            class="form-input" required>
                    </div>
                </div>
<div>
                    <div>
                        <input type="email" name="cor" class="form-control" placeholder="Correo" class="form-input"
                            required>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" name="mov" class="form-control" placeholder="Movil" class="form-input"
                            required>
                    </div>
                </div>
                  <div>
                    <div>
                        <input type="password" name="pas" class="form-control" placeholder="Contraseña" class="form-input"
                            required>
                    </div>
                </div>

                

                <div>
                    <div>
                        <button type="submit">¡Unirme!</button>
                                   </div>
                </div>
            </form>


					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
