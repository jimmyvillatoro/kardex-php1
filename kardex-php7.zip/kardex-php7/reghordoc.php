<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Horario del Docente</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idmat = utf8_decode($_GET['Idmat']);
$Idsal = utf8_decode($_GET['Idsal']);
$Idgra = utf8_decode($_GET['Idgra']);
$Iddoc = utf8_decode($_GET['Iddoc']);
$Iddh = utf8_decode($_GET['Iddh']);
$H = utf8_decode($_GET['H']);
$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM docentes WHERE Iddoc = '".$Iddoc."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row['Nombres'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Registro de Horarios del <span>Docente</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>" title="" class="round active">Atrás</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				

				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	

<p>Docente:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>
<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>


	<div id="splash" align="center">
<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />
				</div>

<h3>Instituto</h3>					
<ul>

<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

$resultado1=mysqli_query($db_connection, "SELECT Escuela FROM escuelas WHERE  Estado=1 && Idesc='".$Idesc."' ORDER BY Idesc  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {

	  $Escuela=$row1['Escuela'];

?> 
	<li><a><?php echo $Escuela; ?></a></li>
 
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>				
</ul>


<h3>Horario del Instituto</h3>

<table class="egt">
<tr>
<th scope="row">Dia</th>
<th>Horario
</th>
</tr>
<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

$resultado3=mysqli_query($db_connection, "SELECT Ideh, Dia, Inicioh, Finh, Horario FROM escuelash WHERE Idesc='".$Idesc."' ORDER BY Ideh  ");

if (mysqli_num_rows($resultado3)>0)
{			  
      while ($row3 =mysqli_fetch_array($resultado3)) 
	  {

     $I=$row3['Ideh'];
	    $D=$row3['Dia'];
     $In=$row3['Inicioh'];
     $F=$row3['Finh'];
     $H=$row3['Horario'];

   
if($D=="Lunes - Viernes"){
?> 
<tr>
<th><?php echo $D; ?></th>
<th><?php echo $H; ?>
</th>
</tr>
<?php
}

if($D=="Sábado - Domingo"){
?> 
<tr>
<th><?php echo $D; ?>
</th>
<th><?php echo $H; ?>
</th>
</tr>
<?php
}

      }
}
mysqli_free_result($resultado3);
mysqli_close($db_connection);
 ?>				
</table>


	
<h3>Registrar Horario del Docente</h3>

        <p>
            <form action="preghordoc.php" method="POST">
                <p align="justify"> Los siguientes datos son necesarios para el sistema de horarios.</p>

<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">

<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>"> 

<input type="hidden" name="Idcic" value="<?php echo utf8_decode($_GET['Idcic']); ?>"> 


<div>
                    <div>

 <select name="dia">
<option value="Lunes" selected>Lunes</option> 
<option value="Martes" >Martes</option>
<option value="Miércoles">Miércoles</option>
<option value="Jueves">Jueves</option>
<option value="Viernes">Viernes</option>
<option value="Sábado">Sábado</option>
<option value="Domingo">Domingo</option>
  </select>
                </div>
                </div>



<div>
<div>
<select name="hor">
<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

$result=mysqli_query($db_connection, "SELECT  Ideh, Horario FROM escuelash WHERE Idesc='".$Idesc."' ORDER BY Ideh ");

if (mysqli_num_rows($result)>0)
{			  
      while ($rowx =mysqli_fetch_array($result)) 
	  {
     $I=$rowx['Ideh'];
     $H=$rowx['Horario'];
?> 

<option value="<?php echo $I; ?>
" selected><?php echo $H; ?>
</option> 

<?php
      }
}
mysqli_free_result($result);
mysqli_close($db_connection);
 ?>				
</select>
</div>
</div>


<div>
<div>

 <select name="est">
<option value="1" selected>Libre</option> 
<option value="2" >Ocupado</option>
<option value="3">Pendiente</option>
  </select>
                </div>
                </div>
                <div>
                    <div>
                        <button type="submit">¡Registrar!</button>
                                   </div>
                </div>
            </form>


<h3>Actualizar Horario del Docente</h3>

<?php
include 'dat/cdb/db.php';
$Iddoc = utf8_decode($_GET['Iddoc']);
$Idesc = utf8_decode($_GET['Idesc']);

$Idcic = utf8_decode($_GET['Idcic']);

$resultado4=mysqli_query($db_connection, "SELECT Iddh, Dia, Horario, Estado FROM docentesh WHERE Iddoc='".$Iddoc."' ORDER BY Iddh  ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
     $I=$row4['Iddh'];
	    $D=$row4['Dia'];
     $H=$row4['Horario'];
     $E=$row4['Estado'];
?> 

<a href="reghordoc.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcic=<?php echo $Idcic; ?>&Iddh=<?php echo $I; ?>&H=<?php echo $H; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>
<?php echo $D; ?>
<?php echo $H; ?>
<a href="pborhordoc.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcic=<?php echo $Idcic; ?>&Iddh=<?php echo $I; ?>"> <img src="dat/ima/borra.png" alt="" width="40" height="40"  class="round"/></a>
</br>

<?php
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>	

        <p>
            <form action="pacthordoc.php" method="POST">

<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">

<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">

<input type="hidden" name="Idcic" value="<?php echo utf8_decode($_GET['Idcic']); ?>">

<input type="hidden" name="Iddh" value="<?php echo utf8_decode($_GET['Iddh']); ?>">

<input type="hidden" name="H" value="<?php echo utf8_decode($_GET['$H']); ?>">
 


<?php
include 'dat/cdb/db.php';
$Iddh = utf8_decode($_GET['Iddh']);

$resultado5=mysqli_query($db_connection, "SELECT Iddh, Dia, Horario, Estado FROM docentesh WHERE Iddh='".$Iddh."'  ");

if (mysqli_num_rows($resultado5)>0)
{			  
      while ($row5 =mysqli_fetch_array($resultado5)) 
	  {
     $Ix=$row5['Iddh'];
	    $Dx=$row5['Dia'];
     $Hx=$row5['Horario'];
     $Ex=$row5['Estado'];

      }
}

if($Ex==1)
$Exx="Libre";

if($Ex==2)
$Exx="Ocupado";

if($Ex==3)
$Exx="Pendiente";

mysqli_free_result($resultado5);
mysqli_close($db_connection);
 ?>				


<div>
                    <div>

 <select name="dia">
<option value="<?php echo $Dx; ?>
" selected><?php echo $Dx; ?>
<option value="Lunes">Lunes</option> 
<option value="Martes" >Martes</option>
<option value="Miércoles">Miércoles</option>
<option value="Jueves">Jueves</option>
<option value="Viernes">Viernes</option>
<option value="Sábado">Sábado</option>
<option value="Domingo">Domingo</option>
<option value="Lunes - Viernes">Lunes - Viernes</option>
<option value="Sábado - Domingo">Sábado - Domingo</option>
  </select>
                </div>
                </div>


<div>
<div>
<select name="hor">
<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

$resultz=mysqli_query($db_connection, "SELECT  Ideh, Horario FROM escuelash WHERE Idesc='".$Idesc."' ORDER BY Ideh ");

if (mysqli_num_rows($resultz)>0)
{			  
      while ($rowz =mysqli_fetch_array($resultz)) 
	  {
     $Iz=$rowz['Ideh'];
     $Hz=$rowz['Horario'];
?> 

<option value="<?php echo $Iz; ?>" selected><?php echo $Hz; ?></option> 

<?php
      }
}
mysqli_free_result($resultz);
mysqli_close($db_connection);
 ?>				
</select>
</div>
</div>


<div>
<div>
 <select name="est">
<option value="<?php echo $Ex; ?>
" selected><?php echo $Exx; ?>
<option value="1">Libre</option> 
<option value="2">Ocupado</option>
<option value="3">Pendiente</option>
  </select>
</div>
</div>


                <div>
                    <div>
                        <button type="submit">¡Actualizar!</button>
                                   </div>
                </div>
            </form>


					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
