<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Cajeros</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idmat = utf8_decode($_GET['Idmat']);
$Idsal = utf8_decode($_GET['Idsal']);
$Idgra = utf8_decode($_GET['Idgra']);
$Iddoc = utf8_decode($_GET['Iddoc']);
$men = utf8_decode($_GET['men']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row['Nombres'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Ver <span>Cajeros</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				

				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);
 ?> </a></p>

	<div id="splash" align="center">
<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />
				</div>


<h3>Cajeros</h3>

<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idmat = utf8_decode($_GET['Idmat']);
$Idgra = utf8_decode($_GET['Idgra']);


$nh = utf8_decode($_GET['nh']);

$resultado4=mysqli_query($db_connection, "SELECT Idusu, Nombres, Apellidos, Correo, Pass, Movil FROM usuarios WHERE Idesc='".$Idesc."' && Estado=2 ORDER BY Apellidos ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
     $Idalu=$row4['Idusu'];
     $nom=$row4['Nombres'];
     $ape=$row4['Apellidos'];
     $c=$row4['Correo'];
     $p=$row4['Pass'];
     $m=$row4['Movil'];
?> 

<?php echo $nom; ?>
   
<?php echo $ape; ?>
   -  <?php echo $c; ?>
 - <?php echo $p; ?>
 - <?php echo $m; ?>

</br>

<?php
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>				


					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
