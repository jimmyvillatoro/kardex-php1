<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Docente Horario y Salon</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';





$Idusu = utf8_decode($_GET['Idusu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idsal = utf8_decode($_GET['Idsal']);

$Idgra = utf8_decode($_GET['Idgra']);

$Iddoc = utf8_decode($_GET['Iddoc']);





$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row['Nombres'];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Ver Docente Horario <span>Salón</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>

				



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>



		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	



<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>



<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>





<h3>Carrera</h3>					

<ul>



<?php

include 'dat/cdb/db.php';

$Idcar = utf8_decode($_GET['Idcar']);



$resultado2=mysqli_query($db_connection, "SELECT Carrera FROM carreras WHERE  Idcar='".$Idcar."' ");



if (mysqli_num_rows($resultado2)>0)

{			  

      while ($row2 =mysqli_fetch_array($resultado2)) 

	  {



	  $Carrera=$row2['Carrera'];



?> 

	<li><a><?php echo $Carrera; ?></a></li>

 

<?php

      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>







<h3>Ciclo</h3>		

<ul>



<?php

include 'dat/cdb/db.php';



$Idcic = utf8_decode($_GET['Idcic']);

$result=mysqli_query($db_connection, "SELECT Ciclo, Sistema, Estado FROM ciclos WHERE Idcic = '".$Idcic."' ");



while ($row1 =mysqli_fetch_array($result)) {

   	 $cic=$row1['Ciclo'];

    $sis=$row1['Sistema'];

    $est=$row1['Estado'];





?> 

	<li><a><?php echo $cic; ?> <?php echo $sis; ?> </a></li>

 

<?php



   }

mysqli_free_result($result);

mysqli_close($db_connection);

?>



</ul>





<h3>Salón</h3>		

<ul>

<?php

include 'dat/cdb/db.php';



$Idsal = utf8_decode($_GET['Idsal']);

$result=mysqli_query($db_connection, "SELECT Turno, Grado, Grupo FROM salones WHERE Idsal = '".$Idsal."' ");



while ($row1 =mysqli_fetch_array($result)) {

   	 $tur=$row1['Turno'];

    $gra=$row1['Grado'];

    $gru=$row1['Grupo'];





?> 

	<li><a><?php echo $tur; ?> <?php echo $gra; ?> <?php echo $gru; ?></a></li>

 

<?php



   }





mysqli_free_result($result);

mysqli_close($db_connection);

?>

</ul>



<h3>Docentes</h3>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idsal = utf8_decode($_GET['Idsal']);



$nh = utf8_decode($_GET['nh']);





$result0=mysqli_query($db_connection, "SELECT gra.Idgra Idgra FROM grados gra, salones sal WHERE gra.Grado=sal.Grado && sal.Idsal='".$Idsal."' && Idcar='".$Idcar."' ");

 



if (mysqli_num_rows($result0)>0)

{

while ($row0 =mysqli_fetch_array($result0)) 

   	 $Idgra=$row0['Idgra'];



}





mysqli_free_result($result0);





$resultado4=mysqli_query($db_connection, "SELECT Iddoc, Nombres, Apellidos FROM docentes WHERE Idesc='".$Idesc."' ORDER BY Apellidos ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

     $Iddoc=$row4['Iddoc'];

     $nom=$row4['Nombres'];

     $ape=$row4['Apellidos'];

?> 



<a href="verdhs.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>&nh=<?php echo $nh; ?> "> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $nom; ?>

  

<?php echo $ape; ?>



</br>



<?php

      }

}

mysqli_free_result($resultado4);

mysqli_close($db_connection);

 ?>				

					

	




<h3>Grado Materia Dia Horario Docente</h3>


<?php

include 'dat/cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idsal = utf8_decode($_GET['Idsal']);
$Iddoc = utf8_decode($_GET['Iddoc']);
$Idgra = utf8_decode($_GET['Idgra']);
$gra = utf8_decode($_GET['gra']);


$Idmat = utf8_decode($_GET['Idmat']);
$nh = utf8_decode($_GET['nh']);


$resultado7=mysqli_query($db_connection, "SELECT det.Idmd Idmd, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idmat Idmat, gra.Grado Grado, gra.Idgra Idgra, doc.Nombres Nom, doc.Apellidos Ape,  dh.Idh Idh, dh.Horas Horas, dh.Dia, Dia, dh.Horario Horario FROM grados gra, materias mat, docentes doc, detallemd det, detalleh dh WHERE gra.Idgra='".$Idgra."' && mat.Idmat=det.Idmat && doc.Iddoc=det.Iddoc && det.Idmd=dh.Idmd && doc.Iddoc='".$Iddoc."' ORDER BY det.Idmd");


if (mysqli_num_rows($resultado7)>0)
{			  

      while ($row7 =mysqli_fetch_array($resultado7)) 

	  {

     $Idmdj=$row7['Idmd'];
     $Idmatj=$row7['Idmat'];
     $mz=$row7['Materia'];
     $hcj=$row7['HorasClase'];
     $Idgraj=$row7['Idgra'];
	    $graz=$row7['Grado'];
     $nj=$row7['Nom'];
     $aj=$row7['Ape'];
     $hj=$row7['Horas'];
     $dj=$row7['Dia'];
     $horj=$row7['Horario'];
     $Ij=$row7['Idh'];

?>

<a href="regrdhs.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>&Idgra=<?php echo $Idgraj; ?>&gra=<?php echo $graz; ?>&Idmat=<?php echo $Idmatj; ?>&Iddoc=<?php echo $Iddoc; ?>&hc=<?php echo $hcj; ?>&Idmd=<?php echo $Idmdj; ?>&Idh=<?php echo $Ij; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $graz; ?>
 - 
<?php echo $mz; ?>
 - 
<?php echo $hcj; ?>
 - 
<?php echo $hj; ?>
 - 
<?php echo $dj; ?>
 - 
<?php echo $horj; ?>
 - 
<?php echo $nj; ?>
 - 
<?php echo $aj; ?>


</br>

<?php

      }

}

mysqli_free_result($resultado7);
mysqli_close($db_connection);

 ?>				

					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>

		

		



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>

	



	

</html>


