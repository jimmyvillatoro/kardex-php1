<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Horarios</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';

$Iddoc = utf8_decode($_GET['Iddoc']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idsal = utf8_decode($_GET['Idsal']);







$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM docentes WHERE Iddoc = '".$Iddoc."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row['Nombres'];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Ver <span>Horarios</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>



<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>" title="" class="round active">Atrás</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>

				



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>



			</ul>				

						



	

		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	



<p>Docente:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>


<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);

 ?> </a></p>



	



<h3>Instituto</h3>					

<ul>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);



$resultado2=mysqli_query($db_connection, "SELECT Escuela FROM escuelas WHERE  Idesc='".$Idesc."' ");



if (mysqli_num_rows($resultado2)>0)

{			  

      while ($row2 =mysqli_fetch_array($resultado2)) 

	  {



	  $escuela=$row2['Escuela'];



?> 

	<li><a><?php echo $escuela; ?></a></li>

 

<?php

      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>







<h3>Horarios de Clases</h3>



<?php

include 'dat/cdb/db.php';

$Iddoc = utf8_decode($_GET['Iddoc']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idsal = utf8_decode($_GET['Idsal']);


$resultado3=mysqli_query($db_connection, "SELECT det.Dia, det.Horario, s.Turno, s.Grado, s.Grupo, c.Ciclo, c.Sistema, doc.Nombres, doc.Apellidos, m.Materia,  car.Carrera FROM  detalleh det,  detallemd md, docentes doc, materias m, ciclos c, salones s, carreras car WHERE doc.Iddoc='".$Iddoc."' && md.Idcic='".$Idcic."' && det.Idmd=md.Idmd && md.Iddoc=doc.Iddoc && md.Idmat=m.Idmat && m.Idcar=car.Idcar && det.Idsal=s.Idsal && md.Idcic=c.Idcic ORDER BY det.Dia, det.Horario ");



if (mysqli_num_rows($resultado3)>0)

{			  

      while ($row3 =mysqli_fetch_array($resultado3)) 

	  {

     $d=$row3['Dia'];
	    $h=$row3['Horario'];
      $dn=$row3['Nombres'];
       $da=$row3['Apellidos'];
       $m=$row3['Materia'];
       $c=$row3['Ciclo'];
        $s=$row3['Sistema'];
        $t=$row3['Turno'];
        $gra=$row3['Grado'];
        $gru=$row3['Grupo'];
        $car=$row3['Carrera'];


?> 





<?php echo $d; ?>

   -   <?php echo $h; ?>
 -  <?php echo $dn; ?>
 -  <?php echo $da; ?>
 -  <?php echo $m; ?>
 

-  <?php echo $c; ?>
 -  <?php echo $s; ?>
 -  <?php echo $t; ?>

-  <?php echo $gra; ?>
 -  <?php echo $gru; ?>
 -  <?php echo $car; ?>



</br>



<?php

      }

}

mysqli_free_result($resultado3);

mysqli_close($db_connection);

 ?>				

						<ul>

<li> 





					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>

		

		



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>

	



	

</html>











