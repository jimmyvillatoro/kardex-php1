<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Materias del Docente</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';





$Idusu = utf8_decode($_GET['Idusu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idsal = utf8_decode($_GET['Idsal']);

$Idgra = utf8_decode($_GET['Idgra']);

$Iddoc = utf8_decode($_GET['Iddoc']);

$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row['Nombres'];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Registro de las <span>Materias</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>



<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>

				



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>



			</ul>				

						



	

		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	



<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>



<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>



<h3>Docentes</h3>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idgra = utf8_decode($_GET['Idgra']);





$nh = utf8_decode($_GET['nh']);



$resultado4=mysqli_query($db_connection, "SELECT Iddoc, Nombres, Apellidos FROM docentes WHERE Idesc='".$Idesc."' ORDER BY Apellidos ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

     $Iddoc=$row4['Iddoc'];

     $nom=$row4['Nombres'];

     $ape=$row4['Apellidos'];

?> 



<a href="vermd.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Iddoc=<?php echo $Iddoc; ?>&nh=<?php echo $nh; ?> "> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $nom; ?>

  

<?php echo $ape; ?>



</br>



<?php

      }

}

mysqli_free_result($resultado4);

mysqli_close($db_connection);

 ?>				

					





	</li>

</ul> 



<h3>Materia  Horas de Clase  Docente</h3>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);

$Iddoc = utf8_decode($_GET['Iddoc']);

$Idcic = utf8_decode($_GET['Idcic']);



$resultado7=mysqli_query($db_connection, "SELECT det.Idmd Idmd, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idmat Idmat,  doc.Nombres Nom, doc.Apellidos Ape FROM  materias mat, docentes doc, detallemd det WHERE det.Idcic='".$Idcic."'  && mat.Idmat=det.Idmat && doc.Iddoc=det.Iddoc &&  doc.Iddoc='".$Iddoc."' && doc.Idesc='".$Idesc."' ORDER BY mat.Materia ");



if (mysqli_num_rows($resultado7)>0)

{			  

      while ($row7 =mysqli_fetch_array($resultado7)) 

	  {



     $Idmdj=$row7['Idmd'];

     $Idmatj=$row7['Idmat'];

     $mz=$row7['Materia'];

     $hcj=$row7['HorasClase'];

     $nj=$row7['Nom'];

     $aj=$row7['Ape'];



?> 



 

<?php echo $mz; ?>

 - 

<?php echo $hcj; ?>

 - 

<?php echo $nj; ?>

 - 

<?php echo $aj; ?>





</br>



<?php

      }

}

mysqli_free_result($resultado7);

mysqli_close($db_connection);

 ?>				





					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>

		

		



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>

	



	

</html>


