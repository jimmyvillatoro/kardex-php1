<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Cobros</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Iddoc= utf8_decode($_GET['Iddoc']);
$Idesc= utf8_decode($_GET['Idesc']);$Idcar= utf8_decode($_GET['Idcar']);
$Idcic= utf8_decode($_GET['Idcic']);
$Idsal= utf8_decode($_GET['Idsal']);

$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Idesc FROM docentes  WHERE Iddoc = '".$Iddoc."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row['Nombres'];
     $Apellidos=$row['Apellidos'];
    $Idescl=$row['Idesc'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<SCRIPT language=JavaScript>

function tick() {
  var hours, minutes, seconds, ap;
  var intHours, intMinutes, intSeconds;
  var today;
  today = new Date();
  intHours = today.getHours();
  intMinutes = today.getMinutes();
  intSeconds = today.getSeconds();

  switch(intHours){
       case 0:
           intHours = 12;
           hours = intHours+":";
           ap = "A.M.";
           break;
       case 12:
           hours = intHours+":";
           ap = "P.M.";
           break;
       case 24:
           intHours = 12;
           hours = intHours + ":";
           ap = "A.M.";
           break;
       default:    
           if (intHours > 12)
           {
             intHours = intHours - 12;
             hours = intHours + ":";
             ap = "P.M.";
             break;
           }
           if(intHours < 12)
           {
             hours = intHours + ":";
             ap = "A.M.";
           }
    }       
       

  if (intMinutes < 10) {
     minutes = "0"+intMinutes+":";
  } else {
     minutes = intMinutes+":";
  }

  if (intSeconds < 10) {
     seconds = "0"+intSeconds+" ";
  } else {
     seconds = intSeconds+" ";
  } 

  timeString = hours+minutes+seconds+ap;
  Clock.innerHTML = timeString;
  window.setTimeout("tick();", 100);
}

window.onload = tick;
</SCRIPT>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Cobros del <span>Docente</span></h1>
				<p>Historial de Cobros </p>
			</div>
			
			<div id="page" class="round">
			<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="docentes.php?Iddoc=<?php echo $Iddoc; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>" title="" class="round active">Atrás</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>


			<div id="wrapper2" class="round">
				<div id="sidebar" class="round">
						<h3>Alumnos</h3>
						<ul>
		   <li>Registro</li>
     <li>Actualizar</li>
     <li>Historial</li>
						</ul>


 <h3>Soporte</h3>
						<ul>
    <li>Soporte</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">

				<h2 align="center">	<a id=Clock style="FONT-SIZE: 40px; COLOR: GREEN; FONT-FAMILY: " class="current"></a></h2>

<p>Docente:<a style="color:orange;"> <?php echo $Nombres; ?> <?php echo $Apellidos; ?></a></p>

<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);
 ?> </a></p>

<div id="wrapper2" class="round">			
<div id="sidebar2" class="round">

<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

if($Idesc<=0)
$Idesc=$Idescl;

$resultado1=mysqli_query($db_connection, "SELECT Idesc, Escuela FROM escuelas WHERE  Estado=1 && Idesc='".$Idesc."' ORDER BY Idesc  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
   $Idesc=$row1['Idesc'];
	  $Escuela=$row1['Escuela'];
?> 
<h3><a style="color:orange;">  <?php echo $Escuela; ?></a></h3>
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>


<?php
include 'dat/cdb/db.php';
$Idalu = utf8_decode($_GET['Idalu']);

$resultado6=mysqli_query($db_connection, "SELECT Fecha, Hora, Folio, Asignada, Cantidad, Materia, Costo, Importe, Descuento, Subtotal, Total, Letras FROM pagos WHERE  Estado=1 && Iddoc='".$Iddoc."' ORDER BY Idpag ");

if (mysqli_num_rows($resultado6)>0)
{			  
      while ($row6 =mysqli_fetch_array($resultado6)){
   $f=$row6['Fecha'];
   $h=$row6['Hora'];
   $fol=$row6['Folio'];
   $asi=$row6['Asignada'];
   $can=$row6['Cantidad'];
   $mat=$row6['Materia'];
   $cos=$row6['Costo'];
   $desc=$row6['Descuento'];
   $imp=$row6['Importe'];
   $sub=$row6['Subtotal'];
   $tot=$row6['Total'];
   $let=$row6['Letras'];
?>
</br><?php echo $f; ?> - <?php echo $h; ?> - <?php echo $fol; ?> - <?php echo $asi; ?> - <?php echo $can; ?> - <?php echo $mat; ?> - <?php echo $cos; ?> - <?php echo $imp; ?> - <?php echo $desc; ?>  - <?php echo $sub; ?> - <?php echo $tot; ?>


</br>
<?php echo $let; ?>
</br>
<?php
      }
}
mysqli_free_result($resultado6);
mysqli_close($db_connection);
 ?>

<div id="splash" align="center">
<img src="dat/ima/kardexb.png" alt="" width="600" height="300" class="round" align="center" />

<!-- End Sidebar -->
</div>
</div>
					<!-- End Content -->
					</div>
					<div style="clear: both"></div>
				<!-- End Wrapper 2 -->
				</div>
			<!-- End Page -->
			</div>
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.
</div>

</body>
</html>
